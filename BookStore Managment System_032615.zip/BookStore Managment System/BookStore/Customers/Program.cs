﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Users;
namespace Customers
{
    internal class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
