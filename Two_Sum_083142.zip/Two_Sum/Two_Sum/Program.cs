﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Two_Sum
{

   
    public class Two_Sum {
        public int[] Two_sum(int[] Nums, int Target)
        {
            
            Dictionary<int, int> map = new Dictionary<int, int>();
            for (int i = 0; i <= Nums.Length; i++)
            {
                int need = Target - Nums[i];
                if (map.ContainsKey(need))
                {
                    return new int[] { map[need], i };
                }
                if (!map.ContainsKey(Nums[i]))
                {
                    map.Add(Nums[i], i);

                }
            }
            return new int[] { };
        } 
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Two_Sum two_sum_ob = new Two_Sum();
            int[] Nums = { 2, 7,3, 11, 15 };
            int Target = 10;
            int[] result = two_sum_ob.Two_sum(Nums, Target);
            Console.WriteLine(result[0]+" , "+result[1]);


            Console.ReadKey();

        }
     
    }
}
